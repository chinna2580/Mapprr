# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Store::Application.config.secret_token = 'a52515ffb3c97c6989d450bd92f42a3fbc8954249f0266ee6854cb55927c1ec299a98abb3bff47980fef86aba72d9864257891650d8b8d16db51584fe5e72147'
